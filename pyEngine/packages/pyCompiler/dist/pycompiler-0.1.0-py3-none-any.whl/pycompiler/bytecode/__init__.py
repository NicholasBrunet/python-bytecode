"""
Bytecode module
"""