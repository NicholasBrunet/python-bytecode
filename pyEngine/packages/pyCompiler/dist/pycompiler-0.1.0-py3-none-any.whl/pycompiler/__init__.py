"""
Primary module for pyCompiler
"""